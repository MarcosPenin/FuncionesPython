print("INICIALES")

nombre=input("Introduce tu nombre:")
apellido1=input("Introduce tu primer apellido:")
apellido2=input("Introduce tu primer apellido:")

n=nombre[0]
a1=apellido1[0]
a2=apellido2[0] 

print(n,a1,a2)