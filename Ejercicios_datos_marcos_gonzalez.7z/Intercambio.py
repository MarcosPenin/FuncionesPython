
print("INTERCAMBIO DEL VALOR DE LAS VARIABLES")

a=float(input("Introduce la variable A:"))
b=float(input("Introduce la variable B:"))

a,b=b,a

print("¡Intercambio! Ahora A vale",a,"y B vale",b)

